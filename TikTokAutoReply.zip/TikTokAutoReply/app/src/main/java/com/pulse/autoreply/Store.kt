package com.pulse.autoreply

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Entry(val time: String, val incoming: String, val reply: String)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("autoreply", Context.MODE_PRIVATE)

    private fun list(c: Context, key: String): MutableList<String> {
        val a = JSONArray(p(c).getString(key, "[]"))
        return MutableList(a.length()) { a.getString(it) }
    }
    private fun save(c: Context, key: String, l: List<String>) {
        p(c).edit().putString(key, JSONArray(l).toString()).apply()
    }

    fun replies(c: Context) = list(c, "replies")
    fun saveReplies(c: Context, l: List<String>) = save(c, "replies", l)
    fun accounts(c: Context) = list(c, "accounts")
    fun saveAccounts(c: Context, l: List<String>) = save(c, "accounts", l)

    fun account(c: Context): String = p(c).getString("account", "") ?: ""
    fun setAccount(c: Context, v: String) = p(c).edit().putString("account", v).apply()
    fun enabled(c: Context) = p(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()
    fun count(c: Context) = p(c).getInt("count", 0)

    @Synchronized
    fun next(c: Context): String? {
        val l = replies(c)
        if (l.isEmpty()) return null
        val i = p(c).getInt("index", 0) % l.size
        p(c).edit().putInt("index", (i + 1) % l.size).apply()
        return l[i]
    }

    @Synchronized
    fun addHistory(c: Context, incoming: String, reply: String) {
        val a = JSONArray(p(c).getString("history", "[]"))
        val o = JSONObject()
            .put("t", SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault()).format(Date()))
            .put("in", incoming).put("r", reply)
        val out = JSONArray()
        out.put(o)
        for (i in 0 until minOf(a.length(), 99)) out.put(a.get(i))
        p(c).edit().putString("history", out.toString()).putInt("count", count(c) + 1).apply()
    }

    fun history(c: Context): List<Entry> {
        val a = JSONArray(p(c).getString("history", "[]"))
        return List(a.length()) {
            val o = a.getJSONObject(it)
            Entry(o.getString("t"), o.getString("in"), o.getString("r"))
        }
    }

    fun clearHistory(c: Context) =
        p(c).edit().putString("history", "[]").putInt("count", 0).apply()
}
