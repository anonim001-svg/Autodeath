package com.pulse.autoreply

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val BG = Color.BLACK
    private val CARD = 0xFF0E0014.toInt()
    private val NEON = 0xFFB026FF.toInt()
    private val DIM = 0xFF5A1A80.toInt()
    private val GRAY = 0xFF9A8AA8.toInt()

    private lateinit var root: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        scroll.addView(root)
        setContentView(scroll)
        scroll.setOnApplyWindowInsetsListener { v, ins ->
            v.setPadding(0, ins.systemWindowInsetTop, 0, ins.systemWindowInsetBottom)
            ins
        }
        render()
    }

    override fun onResume() { super.onResume(); render() }

    private fun hasAccess(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        return s.contains(packageName)
    }

    private fun tv(t: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = GradientDrawable().apply {
            setColor(CARD); cornerRadius = dp(16).toFloat(); setStroke(dp(1), DIM)
        }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
    }

    private fun btn(label: String, big: Boolean = false, filled: Boolean = false, onClick: () -> Unit) =
        TextView(this).apply {
            text = label; gravity = Gravity.CENTER
            textSize = if (big) 20f else 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (filled) Color.BLACK else NEON)
            setPadding(dp(if (big) 20 else 12), dp(if (big) 16 else 8), dp(if (big) 20 else 12), dp(if (big) 16 else 8))
            background = GradientDrawable().apply {
                setColor(if (filled) NEON else Color.TRANSPARENT)
                cornerRadius = dp(12).toFloat(); setStroke(dp(2), NEON)
            }
            setOnClickListener { v ->
                v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(80).withEndAction {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(80).withEndAction { onClick() }.start()
                }.start()
            }
        }

    private fun input(hint: String) = EditText(this).apply {
        this.hint = hint; setHintTextColor(GRAY); setTextColor(Color.WHITE)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat(); setStroke(dp(1), DIM)
        }
    }

    private fun gap(h: Int = 8) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }

    private fun render() {
        root.removeAllViews()

        root.addView(tv("TikTok AutoReply", 26f, NEON, true))
        root.addView(tv("Циклический автоответчик", 13f, GRAY))
        root.addView(gap(12))

        // Статус
        val access = hasAccess()
        val enabled = Store.enabled(this)
        val st = card()
        st.addView(tv(if (access) "● Доступ к уведомлениям: включён" else "○ Доступ к уведомлениям: выключен",
            15f, if (access) NEON else 0xFFFF5577.toInt(), true))
        st.addView(tv("Статус: " + if (enabled && access) "работает" else "остановлен", 14f))
        st.addView(tv("Отправлено ответов: ${Store.count(this)}", 14f))
        if (!access) {
            st.addView(gap())
            st.addView(btn("Выдать доступ к уведомлениям") {
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            })
        }
        root.addView(st)

        // START / STOP
        root.addView(btn(if (enabled) "STOP" else "START", big = true, filled = !enabled) {
            if (!Store.enabled(this)) {
                when {
                    !hasAccess() -> {
                        Toast.makeText(this, "Сначала выдайте доступ к уведомлениям", Toast.LENGTH_LONG).show()
                        startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
                    }
                    Store.replies(this).isEmpty() ->
                        Toast.makeText(this, "Добавьте хотя бы один ответ", Toast.LENGTH_SHORT).show()
                    else -> Store.setEnabled(this, true)
                }
            } else Store.setEnabled(this, false)
            render()
        })
        root.addView(gap(12))

        // Аккаунты
        val ac = card()
        ac.addView(tv("Аккаунт", 17f, NEON, true))
        ac.addView(tv("API TikTok не даёт доступа к личным сообщениям, поэтому приложение читает уведомления. " +
            "Укажите имя аккаунта так, как оно встречается в уведомлении. Если не выбран — отвечает на все.", 12f, GRAY))
        ac.addView(gap())
        val cur = Store.account(this)
        ac.addView(accountRow("Все аккаунты", cur.isEmpty(), null))
        for (a in Store.accounts(this)) ac.addView(accountRow(a, a == cur, a))
        ac.addView(gap())
        val ai = input("Имя аккаунта")
        ac.addView(ai)
        ac.addView(gap())
        ac.addView(btn("Добавить аккаунт") {
            val v = ai.text.toString().trim()
            if (v.isNotEmpty()) {
                val l = Store.accounts(this)
                if (v !in l) l.add(v)
                Store.saveAccounts(this, l); Store.setAccount(this, v); render()
            }
        })
        root.addView(ac)

        // Очередь
        val q = card()
        q.addView(tv("Очередь ответов", 17f, NEON, true))
        val rs = Store.replies(this)
        if (rs.isEmpty()) q.addView(tv("Список пуст", 13f, GRAY))
        rs.forEachIndexed { i, r ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            row.addView(tv("${i + 1}. $r", 15f).apply {
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            row.addView(small("↑") { if (i > 0) { rs.add(i - 1, rs.removeAt(i)); Store.saveReplies(this, rs); render() } })
            row.addView(small("↓") { if (i < rs.size - 1) { rs.add(i + 1, rs.removeAt(i)); Store.saveReplies(this, rs); render() } })
            row.addView(small("✎") { edit(rs, i) })
            row.addView(small("✕") { rs.removeAt(i); Store.saveReplies(this, rs); render() })
            q.addView(row)
        }
        q.addView(gap())
        val ri = input("Новый ответ")
        q.addView(ri)
        q.addView(gap())
        q.addView(btn("Добавить ответ") {
            val v = ri.text.toString().trim()
            if (v.isNotEmpty()) { rs.add(v); Store.saveReplies(this, rs); render() }
        })
        root.addView(q)

        // История
        val h = card()
        h.addView(tv("История ответов", 17f, NEON, true))
        val hs = Store.history(this)
        if (hs.isEmpty()) h.addView(tv("Пока пусто", 13f, GRAY))
        for (e in hs.take(30)) {
            h.addView(gap(6))
            h.addView(tv("${e.time}  →  ${e.reply}", 14f))
            h.addView(tv("на: ${e.incoming}", 12f, GRAY))
        }
        if (hs.isNotEmpty()) {
            h.addView(gap())
            h.addView(btn("Очистить историю") { Store.clearHistory(this); render() })
        }
        root.addView(h)

        // Плавное появление
        for (i in 0 until root.childCount) {
            val v = root.getChildAt(i)
            v.alpha = 0f; v.translationY = dp(20).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 50L).setDuration(300).start()
        }
    }

    private fun small(t: String, onClick: () -> Unit) = tv(t, 20f, NEON, true).apply {
        setPadding(dp(10), dp(4), dp(10), dp(4))
        setOnClickListener { onClick() }
    }

    private fun accountRow(name: String, selected: Boolean, removable: String?): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        row.addView(tv((if (selected) "● " else "○ ") + name, 15f, if (selected) NEON else Color.WHITE, selected).apply {
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnClickListener { Store.setAccount(this@MainActivity, removable ?: ""); render() }
        })
        if (removable != null) row.addView(small("✕") {
            val l = Store.accounts(this); l.remove(removable); Store.saveAccounts(this, l)
            if (Store.account(this) == removable) Store.setAccount(this, "")
            render()
        })
        return row
    }

    private fun edit(rs: MutableList<String>, i: Int) {
        val et = EditText(this).apply { setText(rs[i]); setTextColor(Color.WHITE) }
        AlertDialog.Builder(this).setTitle("Редактировать").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val v = et.text.toString().trim()
                if (v.isNotEmpty()) { rs[i] = v; Store.saveReplies(this, rs); render() }
            }.setNegativeButton("Отмена", null).show()
    }
}
