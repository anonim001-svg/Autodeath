package com.pulse.autoreply

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class ReplyService : NotificationListenerService() {

    companion object {
        val PKGS = setOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")
        private val lastSent = HashMap<String, String>()
        private val lastTime = HashMap<String, Long>()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val c = applicationContext
        if (!Store.enabled(c)) return
        if (sbn.packageName !in PKGS) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val sub = ex.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString() ?: ""

        val acc = Store.account(c)
        if (acc.isNotBlank() && !"$title $text $sub".contains(acc, ignoreCase = true)) return

        val action = n.actions?.firstOrNull { a -> !a.remoteInputs.isNullOrEmpty() } ?: return

        synchronized(lastSent) {
            val key = sbn.key
            val now = System.currentTimeMillis()
            // защита от повторов: эхо собственного ответа и частые обновления одного уведомления
            if (lastSent[key] == text) return
            if (now - (lastTime[key] ?: 0L) < 5000) return

            val reply = Store.next(c) ?: return
            val ri = action.remoteInputs[0]
            val intent = Intent()
            val b = Bundle()
            b.putCharSequence(ri.resultKey, reply)
            RemoteInput.addResultsToIntent(action.remoteInputs, intent, b)
            try {
                action.actionIntent.send(c, 0, intent)
                lastSent[key] = reply
                lastTime[key] = now
                Store.addHistory(c, text, reply)
            } catch (e: PendingIntent.CanceledException) {
                // действие недоступно — ответ не отправлен и в историю не пишется
            }
        }
    }
}
